# baccPRO — Projet Android (APK)

## Structure du projet
```
baccpro_apk/
├── app/
│   ├── src/main/
│   │   ├── java/com/baccpro/app/
│   │   │   └── MainActivity.java      ← WebView fullscreen
│   │   ├── res/
│   │   │   ├── values/strings.xml
│   │   │   ├── values/colors.xml
│   │   │   └── xml/network_security_config.xml
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```

## Comment compiler l'APK

### Option A — Android Studio (recommandé)
1. Télécharge Android Studio : https://developer.android.com/studio
2. Ouvre ce dossier dans Android Studio
3. Build → Generate Signed Bundle / APK → APK → Debug
4. L'APK sera dans : app/build/outputs/apk/debug/app-debug.apk

### Option B — Build en ligne (sans Android Studio)
1. Va sur https://www.appgyver.com ou https://appetize.io
2. Ou utilise GitHub Actions (voir ci-dessous)

### Option C — GitHub Actions (automatique)
1. Crée un repo GitHub avec ce code
2. Le workflow `.github/workflows/build.yml` compile automatiquement l'APK
3. Télécharge l'APK depuis les "Artifacts"

---

## Fonctionnalités de l'APK
- ✅ Plein écran immersif (cache barre navigation + status bar)
- ✅ WebView avec JavaScript activé
- ✅ Stockage local (localStorage, IndexedDB)
- ✅ Cookies persistants
- ✅ Bouton Retour → navigation dans l'app
- ✅ Orientation portrait forcée
- ✅ Barre de progression au chargement
- ✅ Android 5.0+ (API 21+)
